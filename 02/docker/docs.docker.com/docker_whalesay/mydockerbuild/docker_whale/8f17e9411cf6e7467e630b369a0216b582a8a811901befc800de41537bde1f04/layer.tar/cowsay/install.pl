s,%BANGPERL%,!/usr/bin/perl,;
s,%PREFIX%,/usr/local,;
