export TERM=xterm
export LC_CTYPE=en_US.UTF-8
export HOSTNAME=8e7dc56943e6
export INITRD=no
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export LANG=en_US.UTF-8
